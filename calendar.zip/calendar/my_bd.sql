-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Mar 06 Décembre 2016 à 10:02
-- Version du serveur :  5.7.14
-- Version de PHP :  5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `my_bd`
--

-- --------------------------------------------------------

--
-- Structure de la table `phpc_calendars`
--

CREATE TABLE `phpc_calendars` (
  `cid` int(11) UNSIGNED NOT NULL,
  `hours_24` tinyint(1) NOT NULL DEFAULT '0',
  `date_format` tinyint(1) NOT NULL DEFAULT '0',
  `week_start` tinyint(1) NOT NULL DEFAULT '0',
  `subject_max` smallint(5) UNSIGNED NOT NULL DEFAULT '50',
  `events_max` tinyint(4) UNSIGNED NOT NULL DEFAULT '8',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'PHP-Calendar',
  `anon_permission` tinyint(1) NOT NULL DEFAULT '1',
  `timezone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `theme` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `phpc_calendars`
--

INSERT INTO `phpc_calendars` (`cid`, `hours_24`, `date_format`, `week_start`, `subject_max`, `events_max`, `title`, `anon_permission`, `timezone`, `language`, `theme`) VALUES
(1, 0, 0, 0, 50, 8, 'PHP-Calendar', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `phpc_categories`
--

CREATE TABLE `phpc_categories` (
  `catid` int(11) UNSIGNED NOT NULL,
  `cid` int(11) UNSIGNED NOT NULL,
  `gid` int(11) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `text_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bg_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `phpc_events`
--

CREATE TABLE `phpc_events` (
  `eid` int(11) UNSIGNED NOT NULL,
  `cid` int(11) UNSIGNED NOT NULL,
  `owner` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `readonly` tinyint(1) NOT NULL DEFAULT '0',
  `catid` int(11) UNSIGNED DEFAULT NULL,
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `mtime` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `phpc_events`
--

INSERT INTO `phpc_events` (`eid`, `cid`, `owner`, `subject`, `description`, `readonly`, `catid`, `ctime`, `mtime`) VALUES
(7, 1, 1, '', '', 0, NULL, '2016-12-05 16:40:33', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `phpc_groups`
--

CREATE TABLE `phpc_groups` (
  `gid` int(11) NOT NULL,
  `cid` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `phpc_logins`
--

CREATE TABLE `phpc_logins` (
  `uid` int(11) UNSIGNED NOT NULL,
  `series` char(43) COLLATE utf8_unicode_ci NOT NULL,
  `token` char(43) COLLATE utf8_unicode_ci NOT NULL,
  `atime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `phpc_logins`
--

INSERT INTO `phpc_logins` (`uid`, `series`, `token`, `atime`) VALUES
(1, 'jbP1jeKSqYjuVUSE0Pf_usxnzJ2O-8iBW_c36g7ss10', 'nTSXsFYo_ltxU9ID23AYeOLgGxjwWruai4KddFc2Hlw', '2016-12-05 15:49:09');

-- --------------------------------------------------------

--
-- Structure de la table `phpc_occurrences`
--

CREATE TABLE `phpc_occurrences` (
  `oid` int(11) UNSIGNED NOT NULL,
  `eid` int(11) UNSIGNED NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `start_ts` timestamp NULL DEFAULT NULL,
  `end_ts` timestamp NULL DEFAULT NULL,
  `time_type` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `phpc_occurrences`
--

INSERT INTO `phpc_occurrences` (`oid`, `eid`, `start_date`, `end_date`, `start_ts`, `end_ts`, `time_type`) VALUES
(8, 7, NULL, NULL, '2016-12-15 16:00:00', '2016-12-15 17:00:00', 0);

-- --------------------------------------------------------

--
-- Structure de la table `phpc_permissions`
--

CREATE TABLE `phpc_permissions` (
  `cid` int(11) UNSIGNED NOT NULL,
  `uid` int(11) UNSIGNED NOT NULL,
  `read` tinyint(1) NOT NULL,
  `write` tinyint(1) NOT NULL,
  `readonly` tinyint(1) NOT NULL,
  `modify` tinyint(1) NOT NULL,
  `admin` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `phpc_users`
--

CREATE TABLE `phpc_users` (
  `uid` int(11) UNSIGNED NOT NULL,
  `username` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `password_editable` tinyint(1) NOT NULL DEFAULT '1',
  `timezone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gid` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `phpc_users`
--

INSERT INTO `phpc_users` (`uid`, `username`, `password`, `admin`, `password_editable`, `timezone`, `language`, `gid`) VALUES
(1, 'root', 'd41d8cd98f00b204e9800998ecf8427e', 1, 1, 'Europe/Paris', 'fr', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `phpc_user_groups`
--

CREATE TABLE `phpc_user_groups` (
  `gid` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `phpc_version`
--

CREATE TABLE `phpc_version` (
  `version` smallint(5) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `phpc_version`
--

INSERT INTO `phpc_version` (`version`) VALUES
(1);

-- --------------------------------------------------------

--
-- Structure de la table `professionnel`
--

CREATE TABLE `professionnel` (
  `Id_pro` int(20) NOT NULL,
  `Nom_pro` varchar(20) NOT NULL,
  `Num_tel_pro` varchar(15) NOT NULL,
  `Adresse_mailp` varchar(30) NOT NULL,
  `Adresse` varchar(50) NOT NULL,
  `uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `phpc_calendars`
--
ALTER TABLE `phpc_calendars`
  ADD PRIMARY KEY (`cid`);

--
-- Index pour la table `phpc_categories`
--
ALTER TABLE `phpc_categories`
  ADD PRIMARY KEY (`catid`),
  ADD KEY `cid` (`cid`);

--
-- Index pour la table `phpc_events`
--
ALTER TABLE `phpc_events`
  ADD PRIMARY KEY (`eid`);

--
-- Index pour la table `phpc_groups`
--
ALTER TABLE `phpc_groups`
  ADD PRIMARY KEY (`gid`);

--
-- Index pour la table `phpc_logins`
--
ALTER TABLE `phpc_logins`
  ADD PRIMARY KEY (`uid`,`series`);

--
-- Index pour la table `phpc_occurrences`
--
ALTER TABLE `phpc_occurrences`
  ADD PRIMARY KEY (`oid`),
  ADD KEY `eid` (`eid`);

--
-- Index pour la table `phpc_permissions`
--
ALTER TABLE `phpc_permissions`
  ADD UNIQUE KEY `cid` (`cid`,`uid`);

--
-- Index pour la table `phpc_users`
--
ALTER TABLE `phpc_users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Index pour la table `professionnel`
--
ALTER TABLE `professionnel`
  ADD PRIMARY KEY (`Id_pro`),
  ADD KEY `Nom_pro` (`Nom_pro`),
  ADD KEY `uid` (`uid`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `phpc_calendars`
--
ALTER TABLE `phpc_calendars`
  MODIFY `cid` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `phpc_categories`
--
ALTER TABLE `phpc_categories`
  MODIFY `catid` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `phpc_events`
--
ALTER TABLE `phpc_events`
  MODIFY `eid` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `phpc_groups`
--
ALTER TABLE `phpc_groups`
  MODIFY `gid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `phpc_occurrences`
--
ALTER TABLE `phpc_occurrences`
  MODIFY `oid` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `phpc_users`
--
ALTER TABLE `phpc_users`
  MODIFY `uid` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `professionnel`
--
ALTER TABLE `professionnel`
  MODIFY `Id_pro` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
