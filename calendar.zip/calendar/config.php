<?php
define('SQL_HOST',     'localhost');
define('SQL_USER',     'root');
define('SQL_PASSWD',   '');
define('SQL_DATABASE', 'my_bd');
define('SQL_PREFIX',   'phpc_');
define('SQL_TYPE',     'mysqli');
?>
