<?php session_start(); ?>
<?php
include 'connexionn.php';
      if (isset($_POST['login'])) {
        $query=$bdd->query('SELECT * from client WHERE Nom="'.$_POST['login'].'",mot_de_passe="'.$_POST['motdep'].'"');
        $don=$query->fetch();
          if ($_POST['login']==$don['mot_passe_pro']) {
          $_POST['motdep']=$don['mot_de_passe'];
             header('Location:espace_client.php');
          }
          else {
             header('Location:index.php');
          }
        };
?>
