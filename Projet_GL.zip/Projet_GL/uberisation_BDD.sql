﻿-- phpMyAdmin SQL Dump

-- version 4.1.14

-- http://www.phpmyadmin.net

--

-- Client :  127.0.0.1

-- Généré le :  Dim 04 Décembre 2016 à 19:47

-- Version du serveur :  5.6.17

-- Version de PHP :  5.5.12


SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";

SET time_zone = "+00:00";



/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;

/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;

/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;

/*!40101 SET NAMES utf8 */;


--

-- Base de données :  `uberisation`

--


-- --------------------------------------------------------


--

-- Structure de la table `client`

--




CREATE TABLE IF NOT EXISTS `client` (

  `Id` int(4) NOT NULL AUTO_INCREMENT,
  
  `Nom` varchar(20) NOT NULL,
  
  `Prenom` varchar(20) NOT NULL,

  `Num_tel` varchar(15) NOT NULL,

  `Adresse_mail` varchar(30) NOT NULL,

  `Adresse` varchar(50) NOT NULL,

  `mot_de_passe` varchar(20) NOT NULL,

  PRIMARY KEY (`Id`),
  KEY `Nom` (`Nom`)

) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;





-- --------------------------------------------------------


--

-- Structure de la table `demande`

--

CREATE TABLE IF NOT EXISTS `demande` (

  `id_demande` int(4) NOT NULL AUTO_INCREMENT,

  `id_client` int(4) NOT NULL,

  `nom_service` varchar(20) NOT NULL,

  PRIMARY KEY (`id_demande`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;




-- --------------------------------------------------------


--

-- Structure de la table `devis`

--


CREATE TABLE IF NOT EXISTS `devis` (

  `id_devis` int(4) NOT NULL AUTO_INCREMENT,

  `id_service` int(4) NOT NULL,

  `montant` float NOT NULL,

  PRIMARY KEY (`id_devis`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;


-- --------------------------------------------------------



--

-- Structure de la table `professionnel`

--



CREATE TABLE IF NOT EXISTS `professionnel` (

  `Id_pro` int(20) NOT NULL AUTO_INCREMENT,

  `Nom_pro` varchar(20) NOT NULL,

  `Num_tel_pro` varchar(15) NOT NULL,

  `Adresse_mailp` varchar(30) NOT NULL,

  `Adresse` varchar(50) NOT NULL,

  PRIMARY KEY (`Id_pro`),
  KEY `Nom_pro` (`Nom_pro`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;





-- --------------------------------------------------------


--

-- Structure de la table `service`

--


CREATE TABLE IF NOT EXISTS `service` (

  `id_service` int(4) NOT NULL AUTO_INCREMENT,

  `id_pro` int(4) NOT NULL,

  `type_service` varchar(30) NOT NULL,

  `nom_service` varchar(20) NOT NULL,

  PRIMARY KEY (`id_service`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;



-- --------------------------------------------------------


--

-- Structure de la table `tag_service`

--

CREATE TABLE IF NOT EXISTS `tag_service` (

  `id_tag` int(4) NOT NULL AUTO_INCREMENT,

  `id_service` int(4) NOT NULL,

  `nom_tagservice` varchar(50) NOT NULL,

  PRIMARY KEY (`id_tag`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;


