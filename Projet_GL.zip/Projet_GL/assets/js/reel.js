var a = function(pos) {
  var b= pos.coords.latitude,longi = pos.coords.longitude,coords = b+'+'+longi;

	document.getElementById('google_map').setAttribute('src','https://www.google.com/maps/embed/v1/place?key=AIzaSyB_1OmthHTQgVvd7jXj19tSZjz8j5PeTcI&q=loc:' + coords); 
			document.getElementById("map").style.display = 'block';


};

	document.getElementById('get_location').onclick= function(){

   navigator.geolocation.getCurrentPosition(a);
   window.location.href = 'http://ibtissam?variable1=".longi."&variable2=".b/';

   return false ; 
   };
   document.getElementById('get_location1').onclick= function(){

   navigator.geolocation.getCurrentPosition(a);

   return false ; 
   };
   document.getElementById('get_location2').onclick= function(){

   navigator.geolocation.getCurrentPosition(a);

   return false ; 
   };
   document.getElementById('get_location3').onclick= function(){

   navigator.geolocation.getCurrentPosition(a);

   return false ; 
   };
   document.getElementById('get_location4').onclick= function(){

   navigator.geolocation.getCurrentPosition(a);

   return false ; 
   };
   document.getElementById('get_location5').onclick= function(){

   navigator.geolocation.getCurrentPosition(a);

   return false ; 
   };

   