
<?php
   include 'connexionn.php';


if (isset($_POST['nom'])) {


   $req=$bdd->prepare('INSERT INTO client(Nom, Prenom, Num_tel, Adresse_mail, Adresse, mot_de_passe )
                         VALUES( ?, ?, ?, ?, ?, ?)');
             $req->execute(array($_POST['nom'],$_POST['prenom'],$_POST['numtel'],$_POST['addmail'],$_POST['add'],$_POST['motdp']));

}


?>
