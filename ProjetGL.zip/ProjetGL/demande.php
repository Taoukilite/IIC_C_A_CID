<html>
<head>  </head>
<body>
<form method="post" action="">
  <table>
  <tr>
  <th>Service à demander</th>
  <td><input type="text" name="service_demande"><br><br></td>
  </tr>
  <tr>
  <th>Date</th>
  <td><input type="text" name="date_demande">*<br><br></td>
  </tr>
  <tr>
  <th>Lieu</th>
  <td><input type="text" name="lieu"><br><br></td>
  </tr>
  <tr>
  <th></th>
  <td><input type="submit" value="Demander" name="demande" onclick=""/><br><br></td>
  </tr>
  </table>

</form>




</body>



</html>
