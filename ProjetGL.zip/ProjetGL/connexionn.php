<?php

    try
  {

    $bdd = new PDO('mysql:host=localhost;dbname=uberisation', 'root', '');
  }
  catch(Exception $e)
  {

        die('Erreur : '.$e->getMessage());
  }

   ?>
